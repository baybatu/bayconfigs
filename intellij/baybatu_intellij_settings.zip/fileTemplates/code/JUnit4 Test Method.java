@org.junit.Test
public void it_should_${NAME}() {
    //given
        
    //when
    
    //then
}