import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.InjectMocks;
import static org.assertj.core.api.Assertions.assertThat;
#parse("File Header.java")
#set($length_name = $NAME.length() - 4)
#set($new_name = ${StringUtils.removeAndHump(${NAME}, ".")})
#set($new_name = $new_name.substring(0,1).toLowerCase() + $new_name.substring(1,$length_name))
@RunWith(MockitoJUnitRunner.class)
public class ${NAME} {

    @InjectMocks
    private ${CLASS_NAME} ${new_name};
    
    @Test
    public void it_should_${NAME}() {    
        //Given

        //When
        ${BODY}
        //Then
    }
}